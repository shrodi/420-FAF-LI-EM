﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PostDemoMVC.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace PostDemoMVC.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        
        // Action pour «Get»
        public IActionResult Index()
        {
            ViewBag.Title = "Carnet de personnes";

            return View();
        }

        // Action pour «Post»
        [HttpPost]
        public IActionResult Index(Models.Personne personne)
        {
            ViewBag.Title = "Carnet de personnes";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
