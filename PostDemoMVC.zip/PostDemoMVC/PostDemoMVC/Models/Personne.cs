﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PostDemoMVC.Models
{
    public class Personne
    {
        public static List<Personne> Carnet { get; } = new List<Personne>();

        public string Nom { get; set; }

        public string Courriel { get; set; }

        public Personne()
        {
            Carnet.Add(this);
        }
    }
}
